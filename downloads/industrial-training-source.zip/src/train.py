"""Actual supervised pixel/image training. Holdout is evaluated only after selection."""
from pathlib import Path
import os,json,random,time,csv,hashlib,platform,sys
ROOT=Path(__file__).resolve().parents[1]
for key,folder in [('XDG_CACHE_HOME','cache'),('TORCH_HOME','cache/torch'),('MPLCONFIGDIR','cache/matplotlib'),('TMPDIR','tmp')]:
    p=ROOT/folder;p.mkdir(parents=True,exist_ok=True);os.environ[key]=str(p)
import numpy as np
from PIL import Image
import torch
from torch import nn
from torch.utils.data import Dataset,DataLoader,WeightedRandomSampler
from sklearn.metrics import roc_auc_score,precision_recall_fscore_support,confusion_matrix
from model import InspectionNet
SIZE=192;SEED=42;EPOCHS=35
torch.set_num_threads(2);torch.set_num_interop_threads(1)
random.seed(SEED);np.random.seed(SEED);torch.manual_seed(SEED)
class Images(Dataset):
    def __init__(self,records,augment=False):
        self.records=records;self.augment=augment;self.x=[];self.m=[]
        for r in records:
            image=Image.open(ROOT/'data/raw'/r['path']).convert('RGB').resize((SIZE,SIZE),Image.Resampling.BILINEAR)
            mask=Image.open(ROOT/'data/raw'/r['mask']).convert('L').resize((SIZE,SIZE),Image.Resampling.NEAREST) if r['mask'] else Image.new('L',(SIZE,SIZE))
            self.x.append(torch.from_numpy(np.array(image).copy()).permute(2,0,1).float()/255);self.m.append(torch.from_numpy((np.array(mask)>127).astype(np.float32))[None])
    def __len__(self):return len(self.records)
    def __getitem__(self,i):
        x=self.x[i];mask=self.m[i]
        if self.augment:
            k=random.randrange(4);x=torch.rot90(x,k,(-2,-1));mask=torch.rot90(mask,k,(-2,-1))
            if random.random()<.5:x=x.flip(-1);mask=mask.flip(-1)
            x=(x*(.9+random.random()*.2)).clamp(0,1)
        return x,mask,torch.tensor(float(self.records[i]['label']))
def loss_of(mask_logits,cls_logits,mask,labels):
    pixel=nn.functional.binary_cross_entropy_with_logits(mask_logits,mask,pos_weight=torch.tensor(5.))
    p=mask_logits.sigmoid();intersection=(p*mask).flatten(1).sum(1);total=p.flatten(1).sum(1)+mask.flatten(1).sum(1)
    dice=1-((2*intersection+1)/(total+1)).mean();image=nn.functional.binary_cross_entropy_with_logits(cls_logits,labels)
    return pixel+dice+image,pixel,dice,image
def threshold_for(labels,scores):
    options=np.unique(np.r_[0,scores,1]);best=(-1,None)
    for t in options:
        pred=np.asarray(scores)>=t;pr,re,f1,_=precision_recall_fscore_support(labels,pred,average='binary',zero_division=0)
        key=(f1,re,pr,-float(t))
        if best[1] is None or key>best[0]:best=(key,float(t))
    return best[1]
def main():
    split=json.loads((ROOT/'data/split.json').read_text());by={s:[r for r in split['records'] if r['split']==s] for s in ['train','val','test']}
    train=Images(by['train'],True);val=Images(by['val']);normal=sum(r['label']==0 for r in by['train']);anomaly=len(train)-normal
    sampler=WeightedRandomSampler([1/(anomaly if r['label'] else normal) for r in by['train']],len(train),replacement=True,generator=torch.Generator().manual_seed(SEED))
    loader=DataLoader(train,batch_size=10,sampler=sampler,num_workers=0);vloader=DataLoader(val,batch_size=10,shuffle=False,num_workers=0)
    model=InspectionNet();optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001);schedule=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,EPOCHS)
    run=ROOT/'runs/supervised-20261119';run.mkdir(parents=True,exist_ok=True)
    config={'seed':SEED,'epochs':EPOCHS,'input_size':SIZE,'batch_size':10,'optimizer':'AdamW','initial_learning_rate':.001,'weight_decay':.0001,'device':'cpu','threads':2,'architecture':'Small U-Net + binary image head, trained from scratch','parameters':sum(p.numel() for p in model.parameters()),'loss':'pixel BCE (positive weight 5) + soft Dice + image BCE','augmentation':'90-degree rotations, horizontal flip, brightness factor [0.9,1.1]','checkpoint_selection':'lowest validation loss; no test images in fitting or checkpoint selection','split_counts':split['counts'],'versions':{'python':sys.version.split()[0],'torch':str(torch.__version__),'numpy':np.__version__,'pillow':Image.__version__},'platform':platform.platform()}
    (run/'config.json').write_text(json.dumps(config,indent=2));history=[];best=float('inf');started=time.perf_counter()
    for epoch in range(1,EPOCHS+1):
        t=time.perf_counter();model.train();sums=np.zeros(4);count=0
        for x,mask,labels in loader:
            optimizer.zero_grad(set_to_none=True);m,c=model(x);parts=loss_of(m,c,mask,labels);parts[0].backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5);optimizer.step();sums+=np.array([p.item() for p in parts])*len(x);count+=len(x)
        model.eval();vsum=0;vn=0;vlabels=[];vscores=[]
        with torch.inference_mode():
            for x,mask,labels in vloader:
                m,c=model(x);loss=loss_of(m,c,mask,labels)[0];vsum+=loss.item()*len(x);vn+=len(x);vlabels+=labels.tolist();vscores+=c.sigmoid().tolist()
        row={'epoch':epoch,'train_loss':float(sums[0]/count),'pixel_loss':float(sums[1]/count),'dice_loss':float(sums[2]/count),'classification_loss':float(sums[3]/count),'validation_loss':vsum/vn,'validation_auroc':float(roc_auc_score(vlabels,vscores)),'learning_rate':optimizer.param_groups[0]['lr'],'epoch_seconds':time.perf_counter()-t,'elapsed_seconds':time.perf_counter()-started}
        if row['validation_loss']<best:
            best=row['validation_loss'];torch.save({'state_dict':model.state_dict(),'config':config,'epoch':epoch,'validation_loss':best},ROOT/'models/inspection-best.pt')
        history.append(row);(run/'history.json').write_text(json.dumps(history,indent=2));schedule.step();print(json.dumps(row),flush=True)
    checkpoint=torch.load(ROOT/'models/inspection-best.pt',map_location='cpu',weights_only=True);model.load_state_dict(checkpoint['state_dict']);model.eval();vlabels=[];vscores=[];vp=[];vm=[]
    with torch.inference_mode():
        for x,mask,labels in vloader:
            m,c=model(x);vlabels+=labels.tolist();vscores+=c.sigmoid().tolist();vp.extend(m.sigmoid().numpy());vm.extend(mask.numpy())
    image_threshold=threshold_for(vlabels,vscores);pixel_options=[]
    vp=np.asarray(vp);vm=np.asarray(vm)>0.5
    for t in np.arange(.1,.91,.05):
        p=vp>=t;tp=np.logical_and(p,vm).sum();fp=np.logical_and(p,~vm).sum();fn=np.logical_and(~p,vm).sum();pixel_options.append((float(2*tp/max(1,2*tp+fp+fn)),float(t)))
    pixel_threshold=max(pixel_options)[1];thresholds={'image_threshold':image_threshold,'pixel_threshold':pixel_threshold,'source':'validation split only; thresholds frozen before holdout evaluation','selected_epoch':checkpoint['epoch'],'validation_loss':best,'validation_samples':len(val)}
    (ROOT/'models/thresholds.json').write_text(json.dumps(thresholds,indent=2));(run/'finished.json').write_text(json.dumps({'training_seconds':time.perf_counter()-started,'selected_epoch':checkpoint['epoch'],'weights_sha256':hashlib.sha256((ROOT/'models/inspection-best.pt').read_bytes()).hexdigest(),'thresholds':thresholds},indent=2));print(json.dumps({'training_complete':True,'selected_epoch':checkpoint['epoch'],'thresholds':thresholds}),flush=True)
if __name__=='__main__':main()
