"""Frozen holdout evaluation and actual output artifacts, including every error."""
from pathlib import Path
import json,csv,hashlib,time,platform
import numpy as np
from PIL import Image
import torch
from sklearn.metrics import roc_auc_score,precision_recall_fscore_support,confusion_matrix
from inference import Inspector,ROOT
torch.set_num_threads(2);torch.set_num_interop_threads(1)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    out=ROOT/'runs/supervised-20261119';outputs=out/'predictions';outputs.mkdir(exist_ok=True)
    records=json.loads((ROOT/'data/split.json').read_text())['records'];test=[r for r in records if r['split']=='test'];inspector=Inspector()
    # Warm-up is explicitly outside the recorded latency distribution.
    warm=Image.open(ROOT/'data/raw'/test[0]['path'])
    for _ in range(5):inspector.predict(warm)
    rows=[];tp=fp=fn=0;all_heat=[];all_masks=[]
    for index,r in enumerate(test):
        image=Image.open(ROOT/'data/raw'/r['path']);result=inspector.predict(image);heat=result.pop('heat');mask=result.pop('mask');truth=np.array(Image.open(ROOT/'data/raw'/r['mask']).convert('L').resize((192,192),Image.Resampling.NEAREST))>127 if r['mask'] else np.zeros((192,192),bool)
        tp+=np.logical_and(mask,truth).sum();fp+=np.logical_and(mask,~truth).sum();fn+=np.logical_and(~mask,truth).sum();all_heat.append(heat.ravel());all_masks.append(truth.ravel())
        identity=f'test-{index:03d}-{r["kind"]}';rgb=image.convert('RGB');rgb.thumbnail((700,700));rgb.save(outputs/(identity+'.webp'),'WEBP',quality=85,method=6)
        Image.fromarray((mask*255).astype('uint8')).save(outputs/(identity+'-prediction.png'));Image.fromarray((truth*255).astype('uint8')).save(outputs/(identity+'-truth.png'))
        rgba=np.zeros((*heat.shape,4),np.uint8);rgba[...,0]=255;rgba[...,1]=(160*(1-heat)).astype('uint8');rgba[...,2]=65;rgba[...,3]=(heat*210).astype('uint8');Image.fromarray(rgba).save(outputs/(identity+'-heat.png'))
        row={**{k:v for k,v in r.items() if k not in ['mask_sha256']},**result,'correct':int(result['predicted_label']==r['label']),'assets':{'image':identity+'.webp','prediction':identity+'-prediction.png','truth':identity+'-truth.png','heatmap':identity+'-heat.png'}};rows.append(row)
        print(json.dumps({'evaluated':index+1,'total':len(test),'source':r['path'],'true_label':r['label'],'prediction':result['predicted_label'],'score':round(result['score'],5),'pipeline_ms':round(result['timing']['pipeline_ms'],3)}),flush=True)
    labels=[r['label'] for r in rows];pred=[r['predicted_label'] for r in rows];scores=[r['score'] for r in rows];precision,recall,f1,_=precision_recall_fscore_support(labels,pred,average='binary',zero_division=0);tn,fp_image,fn_image,tp_image=map(int,confusion_matrix(labels,pred,labels=[0,1]).ravel());accuracy=sum(r['correct'] for r in rows)/len(rows);n=len(rows);z=1.96;center=(accuracy+z*z/(2*n))/(1+z*z/n);half=z*((accuracy*(1-accuracy)/n+z*z/(4*n*n))**.5)/(1+z*z/n)
    latency={key:{'median':float(np.median([r['timing'][key] for r in rows])),'p95':float(np.percentile([r['timing'][key] for r in rows],95)),'min':float(min(r['timing'][key] for r in rows)),'max':float(max(r['timing'][key] for r in rows))} for key in ['preprocess_ms','model_ms','postprocess_ms','pipeline_ms']}
    report={'created_at':time.strftime('%Y-%m-%dT%H:%M:%S%z'),'model_sha256':sha(ROOT/'models/inspection-best.pt'),'train_source_sha256':sha(ROOT/'src/train.py'),'inference_source_sha256':sha(ROOT/'src/inference.py'),'dataset':json.loads((ROOT/'data/split.json').read_text())['counts'],'test_samples':n,'image_metrics':{'accuracy':accuracy,'accuracy_wilson95':[center-half,center+half],'precision':float(precision),'recall':float(recall),'f1':float(f1),'auroc':float(roc_auc_score(labels,scores)),'true_negative':tn,'false_positive':fp_image,'false_negative':fn_image,'true_positive':tp_image},'pixel_metrics':{'dice':float(2*tp/max(1,2*tp+fp+fn)),'iou':float(tp/max(1,tp+fp+fn)),'auroc':float(roc_auc_score(np.concatenate(all_masks),np.concatenate(all_heat)))},'thresholds':inspector.config,'latency_ms':latency,'latency_scope':'66 held-out individual images after five warm-ups; CPU two threads; 192x192. Includes resize/normalization, neural inference and thresholding; excludes network, image-file read, camera, controller and robot, and PNG UI encoding.','platform':platform.platform(),'per_type':{kind:{'count':sum(r['kind']==kind for r in rows),'correct':sum(r['correct'] for r in rows if r['kind']==kind),'errors':sum(not r['correct'] for r in rows if r['kind']==kind)} for kind in sorted({r['kind'] for r in rows})},'limitations':['Custom supervised split, not official unsupervised MVTec benchmark','No exact image hash overlap; independent production batch metadata unavailable','Single public product category; not a validation of actual factory equipment','Scores are not calibrated probabilities; errors are all retained'],'rows':rows}
    (out/'test-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    with (out/'test-predictions.csv').open('w',newline='') as file:
        fields=['path','kind','label','predicted_label','score','threshold','action','correct','pipeline_ms'];writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader()
        for r in rows:writer.writerow({**{k:r[k] for k in fields if k!='pipeline_ms'},'pipeline_ms':r['timing']['pipeline_ms']})
    print(json.dumps({'evaluation_complete':True,'image_metrics':report['image_metrics'],'pixel_metrics':report['pixel_metrics'],'latency_ms':latency},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
