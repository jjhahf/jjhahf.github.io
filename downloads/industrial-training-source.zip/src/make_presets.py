"""Select fixed holdout images for an explained, one-click walkthrough."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
SITE=Path('/Users/lu/Documents/ChatGPT/智网/build-index-20261112')
run=ROOT/'runs/supervised-20261119'
report=json.loads((run/'test-report.json').read_text())
rows=report['rows']
specs=[('normal','正常件放行','表面正常，看看模型如何放行。',lambda r:r['kind']=='good' and r['action']=='pass'),('scratch','划伤件剔除','观察表面划伤与预测热区。',lambda r:r['kind']=='scratch' and r['action']=='reject'),('bent','变形件剔除','外形改变后，模型会怎样判断？',lambda r:r['kind']=='bent' and r['action']=='reject'),('color','异色件剔除','对照异常颜色与模型输出。',lambda r:r['kind']=='color' and r['action']=='reject'),('flip','翻面件剔除','放反的零件也需要识别。',lambda r:r['kind']=='flip' and r['action']=='reject'),('review','临界件复核','正常件也可能误报，保留这次真实失误。',lambda r:r['kind']=='good' and r['action']=='review' and r['predicted_label']==1)]
items=[];local=[]
for slug,title,description,rule in specs:
 row=next(r for r in rows if rule(r));result={k:row[k] for k in ['score','threshold','predicted_label','action','box','timing','correct']}
 for name in row['assets'].values():shutil.copy2(run/'predictions'/name,SITE/'src/assets/industrial-real'/name)
 item={'id':slug,'title':title,'description':description,'truth':'正常件' if row['label']==0 else {'scratch':'表面划伤','bent':'外形变形','color':'表面异色','flip':'零件翻面'}[row['kind']],'image':'../assets/industrial-real/'+row['assets']['image'],'heatmap':'../assets/industrial-real/'+row['assets']['heatmap'],'result':result}
 items.append(item);local.append({'id':slug,'path':row['path'],'sha256':row['sha256']})
payload={'selection_note':'为讲解放行、剔除和复核而选取的六张保留测试图，不用于重新估计准确率；完整66张测试指标保持原记录。','model_sha256':report['model_sha256'],'presets':items,'sequence':['normal','scratch','review']}
(SITE/'src/industrial-presets.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2))
(ROOT/'data/presets.json').write_text(json.dumps(local,ensure_ascii=False,indent=2))
print(json.dumps({'presets':len(items),'batch':payload['sequence'],'uses':'Original held-out PNG pixels for live inference; saved real outputs for public walkthrough.'},ensure_ascii=False))
