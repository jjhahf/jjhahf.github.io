"""Production inference entry: consumes image pixels, never dataset labels or masks."""
from pathlib import Path
import io,json,time,base64
import numpy as np
from PIL import Image
import torch
from model import InspectionNet
ROOT=Path(__file__).resolve().parents[1]
class Inspector:
    def __init__(self):
        self.checkpoint=torch.load(ROOT/'models/inspection-best.pt',map_location='cpu',weights_only=True)
        self.model=InspectionNet();self.model.load_state_dict(self.checkpoint['state_dict']);self.model.eval()
        self.config=json.loads((ROOT/'models/thresholds.json').read_text());self.size=self.checkpoint['config']['input_size']
    def predict(self,image):
        start=time.perf_counter();rgb=image.convert('RGB').resize((self.size,self.size),Image.Resampling.BILINEAR)
        x=torch.from_numpy(np.array(rgb).copy()).permute(2,0,1).float()[None]/255;ready=time.perf_counter()
        with torch.inference_mode():mask_logits,cls_logits=self.model(x)
        done=time.perf_counter();heat=mask_logits[0,0].sigmoid().numpy();classifier_score=float(cls_logits.sigmoid()[0]);k=max(1,int(heat.size*.01));segmentation_score=float(np.partition(heat.ravel(),heat.size-k)[-k:].mean());source=self.config.get('score_source','classifier');score=classifier_score if source=='classifier' else segmentation_score if source=='segmentation' else (classifier_score+segmentation_score)/2;mask=heat>=self.config['pixel_threshold'];threshold=self.config['image_threshold'];positive=score>=threshold
        action='review' if abs(score-threshold)<.05 else 'reject' if positive else 'pass'
        ys,xs=np.nonzero(mask);box=[float(xs.min()/self.size),float(ys.min()/self.size),float((xs.max()+1)/self.size),float((ys.max()+1)/self.size)] if len(xs) else None
        end=time.perf_counter()
        return {'score':score,'classifier_score':classifier_score,'segmentation_score':segmentation_score,'score_source':source,'threshold':threshold,'pixel_threshold':self.config['pixel_threshold'],'predicted_label':int(positive),'action':action,'mask_area_ratio':float(mask.mean()),'box':box,'timing':{'preprocess_ms':(ready-start)*1000,'model_ms':(done-ready)*1000,'postprocess_ms':(end-done)*1000,'pipeline_ms':(end-start)*1000},'heat':heat,'mask':mask}
    def json_result(self,image):
        result=self.predict(image);mask=Image.fromarray((result.pop('mask')*255).astype('uint8'));heat=result.pop('heat');colored=np.zeros((*heat.shape,4),dtype=np.uint8);colored[...,0]=255;colored[...,1]=(160*(1-heat)).astype('uint8');colored[...,2]=65;colored[...,3]=(heat*210).astype('uint8')
        def png(im):
            out=io.BytesIO();im.save(out,'PNG');return base64.b64encode(out.getvalue()).decode()
        result['input_png']='data:image/png;base64,'+png(image.convert('RGB').resize((self.size,self.size),Image.Resampling.BILINEAR));result['mask_png']='data:image/png;base64,'+png(mask);result['heatmap_png']='data:image/png;base64,'+png(Image.fromarray(colored));result['scope']='本机真实模型推理；机械臂未连接；异常分数不是校准后的准确率。';return result
