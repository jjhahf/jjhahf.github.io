"""Publish genuine evidence into the portfolio; no model weights or credentials."""
from pathlib import Path
from collections import Counter
import json,shutil,zipfile,hashlib,math
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
SITE=Path('/Users/lu/Documents/ChatGPT/智网/build-index-20261112')
def main():
    run=ROOT/'runs/supervised-20261119';report=json.loads((run/'test-report.json').read_text());config=json.loads((run/'config.json').read_text());finished=json.loads((run/'finished.json').read_text());split=json.loads((ROOT/'data/split.json').read_text());history=json.loads((run/'history.json').read_text());rows=report['rows'];assets=SITE/'src/assets/industrial-real';assets.mkdir(parents=True,exist_ok=True)
    selection=[i for i,r in enumerate(rows) if not r['correct']][:12]
    for kind in ['good','scratch','bent','color','flip']:
        for i,r in enumerate(rows):
            if r['kind']==kind and i not in selection:selection.append(i);break
    for i,r in enumerate(rows):
        if len(selection)>=18:break
        if i not in selection:selection.append(i)
    selection=selection[:18]
    # Control replay uses the first holdout sample per category, not handpicked success.
    replay=[]
    for kind in ['good','scratch','good','bent','color','flip']:
        used={r['path'] for r in replay};r=next(r for r in rows if r['kind']==kind and r['path'] not in used);replay.append(r)
    for r in [rows[i] for i in selection]+replay:
        for name in r['assets'].values():shutil.copy2(run/'predictions'/name,assets/name)
    training_images=[]
    for kind in ['good','scratch','bent','color','flip']:
        examples=[r for r in split['records'] if r['split']=='train' and r['kind']==kind][:4 if kind=='good' else 2]
        for r in examples:
            name=f'train-{len(training_images):02d}-{kind}';image=Image.open(ROOT/'data/raw'/r['path']).convert('RGB');image.thumbnail((700,700));image.save(assets/(name+'.webp'),'WEBP',quality=84,method=6);mask=None
            if r['mask']:
                mask=name+'-truth.png';Image.open(ROOT/'data/raw'/r['mask']).convert('L').resize((700,700),Image.Resampling.NEAREST).save(assets/mask)
            training_images.append({'kind':kind,'image':name+'.webp','mask':mask,'sha256':r['sha256'],'source':r['path']})
    evidence={'completed_at':report['created_at'],'counts':report['dataset'],'config':config,'history':history,'selected_epoch':report['thresholds']['selected_epoch'],'thresholds':report['thresholds'],'metrics':report['image_metrics'],'pixel_metrics':report['pixel_metrics'],'latency':report['latency_ms'],'model_sha256':report['model_sha256'],'training_seconds':finished['training_seconds'],'gallery':[rows[i] for i in selection],'gallery_selection':'First up to twelve mistakes, then each ground-truth type and remaining samples, capped at eighteen; full test CSV contains every holdout item.','rows':rows,'training_images':training_images,'limits':report['limitations']}
    (SITE/'src/industrial-training.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
    case=json.loads((SITE/'src/industrial-case.json').read_text());titles={'good':'正常表面','scratch':'表面划伤','bent':'外形变形','color':'表面异色','flip':'零件翻面'}
    case['samples']=[{'id':i+1,'kind':r['kind'],'title':titles[r['kind']],'action':r['action'],'image':r['assets']['image'],'mask':r['assets']['prediction'],'heatmap':r['assets']['heatmap'],'ground_truth_mask':r['assets']['truth'],'asset_group':'industrial-real','width':700,'height':700,'source_label':r['kind'],'prediction':{k:r[k] for k in ['score','threshold','predicted_label','action','correct','timing']},'source_sha256':r['sha256']} for i,r in enumerate(replay)]
    case['design']['inference_ms']=max(5,math.ceil(report['latency_ms']['model_ms']['p95']))
    case['design'].update(capture_ms=math.ceil(report['latency_ms']['preprocess_ms']['p95'])+5,communication_ms=math.ceil(report['latency_ms']['postprocess_ms']['p95'])+7,preprocess_reference_ms=math.ceil(report['latency_ms']['preprocess_ms']['p95']),postprocess_reference_ms=math.ceil(report['latency_ms']['postprocess_ms']['p95']),camera_allowance_ms=5,communication_allowance_ms=7)
    case.update(modified_at='2026-11-19',description='真实训练金属件缺陷分割模型，展示保留测试集、预测热图、逐轮日志与本机登录识别；机械臂控制部分仍待设备接入。',runtime='本机已训练模型的真实离线结果与登录识别服务；机械臂仅回放控制流程，未接入现场。',model_sha256=report['model_sha256'],local_model_service='http://127.0.0.1:4288/')
    (SITE/'src/industrial-case.json').write_text(json.dumps(case,ensure_ascii=False,indent=2))
    download=SITE/'src/downloads';download.mkdir(exist_ok=True)
    shutil.copy2(run/'test-predictions.csv',download/'industrial-test-predictions.csv');shutil.copy2(run/'history.json',download/'industrial-training-history.json');shutil.copy2(ROOT/'data/split.json',download/'industrial-data-split.json');shutil.copy2(run/'test-report.json',download/'industrial-test-report.json')
    code=SITE/'src/training-code/industrial';code.mkdir(parents=True,exist_ok=True)
    for file in (ROOT/'src').iterdir():
        if file.is_file() and not file.name.startswith('._') and file.suffix in ['.py','.html','.css','.js','.json']:shutil.copy2(file,code/file.name)
    for name in ['README.md','requirements.txt']:
        if (ROOT/name).exists():shutil.copy2(ROOT/name,code/name)
    with zipfile.ZipFile(download/'industrial-training-source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for file in code.iterdir():
            if file.is_file() and not file.name.startswith('._'):z.write(file,'src/'+file.name if file.suffix in ['.py','.html','.css','.js','.json'] else file.name)
        z.write(ROOT/'data/presets.json','data/presets.json');z.write(ROOT/'data/remote-manifest.json','data/remote-manifest.json');z.write(ROOT/'data/split.json','data/split.json');z.write(run/'history.json','evidence/history.json');z.write(run/'test-report.json','evidence/test-report.json');z.write(run/'calibration.json','evidence/calibration.json')
    provenance=SITE/'docs/project-sources/industrial-inspection.json';p=json.loads(provenance.read_text());p['real_experiment']={'date':'2026-11-19','path':str(ROOT),'model_sha256':report['model_sha256'],'counts':report['dataset'],'training_epochs':len(history),'source_revision':split['revision'],'exact_hash_cross_split_overlap':0,'protocol':split['protocol'],'report_file':str(run/'test-report.json'),'weights_public':False,'ground_truth_used_during_inference':False,'hardware_connected':False};p['scope']='已实际训练并测评的工业缺陷模型与真实本机识别；未接入现场硬件';provenance.write_text(json.dumps(p,ensure_ascii=False,indent=2));print(json.dumps({'evidence_exported':True,'gallery':len(selection),'training_images':len(training_images),'metrics':report['image_metrics']},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
