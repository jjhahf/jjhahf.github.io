"""Predeclared head selection on VALIDATION only; does not read the holdout pixels."""
import json,hashlib
import numpy as np
from PIL import Image
import torch
from sklearn.metrics import roc_auc_score,precision_recall_fscore_support
from inference import ROOT,Inspector
torch.set_num_threads(2);torch.set_num_interop_threads(1)
def main():
    rows=[r for r in json.loads((ROOT/'data/split.json').read_text())['records'] if r['split']=='val'];model=Inspector();labels=[];scores={'classifier':[],'segmentation':[],'fused':[]}
    for r in rows:
        p=model.predict(Image.open(ROOT/'data/raw'/r['path']));labels.append(r['label']);scores['classifier'].append(p['classifier_score']);scores['segmentation'].append(p['segmentation_score']);scores['fused'].append((p['classifier_score']+p['segmentation_score'])/2)
    options=[]
    for name,values in scores.items():
        auc=float(roc_auc_score(labels,values));best=None
        for threshold in np.unique(np.r_[0,values,1]):
            pred=np.asarray(values)>=threshold;precision,recall,f1,_=precision_recall_fscore_support(labels,pred,average='binary',zero_division=0);key=(f1,recall,precision,-threshold)
            if best is None or key>best[0]:best=(key,float(threshold))
        options.append({'source':name,'auroc':auc,'f1':float(best[0][0]),'threshold':best[1]})
    chosen=max(options,key=lambda x:(x['auroc'],x['f1']));config=model.config;config.update(score_source=chosen['source'],image_threshold=chosen['threshold'],score_selection='best validation AUROC among three predeclared outputs; then validation F1 threshold; no holdout used',score_candidates=options)
    (ROOT/'models/thresholds.json').write_text(json.dumps(config,indent=2));report={'calibration_samples':len(rows),'candidates':options,'chosen':chosen,'weights_sha256':hashlib.sha256((ROOT/'models/inspection-best.pt').read_bytes()).hexdigest(),'test_images_read':0};(ROOT/'runs/supervised-20261119/calibration.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
if __name__=='__main__':main()
