"""Loopback-only authenticated, rate-limited model service; no hardware control."""
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from collections import defaultdict,deque
import base64,hashlib,hmac,io,json,os,secrets,threading,time
from urllib.parse import urlsplit
from PIL import Image,UnidentifiedImageError
import torch
from inference import Inspector,ROOT
torch.set_num_threads(2);torch.set_num_interop_threads(1)
PRIVATE=Path.home()/'.config/此刻灵感/工业质检'
PRIVATE.mkdir(parents=True,exist_ok=True);PRIVATE.chmod(0o700)
AUTH=PRIVATE/'auth.json';INITIAL=PRIVATE/'初始账号.json'
def private_write(path,data):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(fd,'w') as file:file.write(data)
    path.chmod(0o600)
if not AUTH.exists():
    password=secrets.token_urlsafe(24);salt=secrets.token_bytes(16);digest=hashlib.scrypt(password.encode(),salt=salt,n=16384,r=8,p=1).hex()
    private_write(AUTH,json.dumps({'username':'quality_admin','salt':salt.hex(),'password_hash':digest}))
    private_write(INITIAL,json.dumps({'网址':'http://127.0.0.1:4288/','账号':'quality_admin','初始密码':password},ensure_ascii=False,indent=2));del password
presets={row['id']:row for row in json.loads((ROOT/'data/presets.json').read_text())}
account=json.loads(AUTH.read_text());sessions={};attempts=defaultdict(deque);rates=defaultdict(deque);quota_path=ROOT/'runs/service-quota.json';quotas=json.loads(quota_path.read_text()) if quota_path.exists() else {};lock=threading.Lock();inference_lock=threading.Semaphore(1);model=Inspector();audit=ROOT/'runs/service-audit.jsonl'
def audit_event(action,user=None,**extra):
    row={'time':time.strftime('%Y-%m-%dT%H:%M:%S%z'),'action':action,'user':user,**extra}
    with lock:
        if audit.exists() and audit.stat().st_size>5_000_000:audit.replace(audit.with_suffix('.previous.jsonl'))
        with audit.open('a') as file:file.write(json.dumps(row,ensure_ascii=False)+'\n')
class Handler(BaseHTTPRequestHandler):
    server_version='LocalInspection/1';protocol_version='HTTP/1.1'
    def setup(self):
        super().setup();self.connection.settimeout(15)
    def log_message(self,*args):pass
    def respond(self,status,data,kind='application/json; charset=utf-8',cookie=None):
        if isinstance(data,(dict,list)):data=json.dumps(data,ensure_ascii=False).encode()
        if isinstance(data,str):data=data.encode()
        self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('X-Frame-Options','DENY');self.send_header('Referrer-Policy','no-referrer')
        if cookie:self.send_header('Set-Cookie',cookie)
        self.end_headers();self.wfile.write(data)
    def session(self):
        cookie=self.headers.get('Cookie','');token=next((p.strip().split('=',1)[1] for p in cookie.split(';') if p.strip().startswith('inspection_session=')),None)
        with lock:
            session=sessions.get(token)
            if session and session['expires']>time.time():return token,session
        return None,None
    def body(self,limit=4_000_000):
        size=int(self.headers.get('Content-Length','0'))
        if size<=0 or size>limit:raise ValueError('请求内容为空或超过大小限制')
        return json.loads(self.rfile.read(size))
    def do_GET(self):
        path=urlsplit(self.path).path
        if path=='/':
            html=(ROOT/'src/workbench.html').read_text().replace('{{PRESET_CSS}}',(ROOT/'src/quick.css').read_text()).replace('{{PRESET_SECTION}}',(ROOT/'src/quick-fragment.html').read_text()).replace('{{PRESET_SCRIPT}}',(ROOT/'src/quick.js').read_text())
            return self.respond(200,html,'text/html; charset=utf-8')
        if path.startswith('/api/preset-images/'):
            preset=presets.get(path.removeprefix('/api/preset-images/'))
            if not preset:return self.respond(404,{'error':'预设图片不存在'})
            return self.respond(200,(ROOT/'data/raw'/preset['path']).read_bytes(),'image/png')
        _,session=self.session()
        if not session:return self.respond(401,{'error':'请先登录'})
        if path=='/api/session':return self.respond(200,{'username':session['username'],'csrf':session['csrf'],'model_input':model.size})
        return self.respond(404,{'error':'地址不存在'})
    def do_POST(self):
        origin=self.headers.get('Origin')
        if origin and origin not in ['http://127.0.0.1:4288','http://localhost:4288']:return self.respond(403,{'error':'来源校验未通过'})
        path=urlsplit(self.path).path
        try:data=self.body(4000 if path=='/api/login' else 4_000_000)
        except Exception:return self.respond(400,{'error':'请求格式无效或文件过大'})
        if path=='/api/login':
            key=self.client_address[0];now=time.time()
            with lock:
                history=attempts[key]
                while history and now-history[0]>300:history.popleft()
                if len(history)>=8:return self.respond(429,{'error':'登录尝试过多，请五分钟后重试'})
                history.append(now)
            password=str(data.get('password',''))[:200];digest=hashlib.scrypt(password.encode(),salt=bytes.fromhex(account['salt']),n=16384,r=8,p=1).hex()
            valid=hmac.compare_digest(str(data.get('username','')),account['username']) and hmac.compare_digest(digest,account['password_hash'])
            if not valid:audit_event('login_failed');return self.respond(401,{'error':'账号或密码不正确'})
            token=secrets.token_urlsafe(32);session={'username':account['username'],'expires':now+8*3600,'csrf':secrets.token_urlsafe(24)}
            with lock:sessions[token]=session
            audit_event('login_success',session['username']);return self.respond(200,{'username':session['username'],'csrf':session['csrf']},cookie='inspection_session='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800')
        token,session=self.session()
        if not session:return self.respond(401,{'error':'请先登录'})
        if not hmac.compare_digest(self.headers.get('X-CSRF-Token',''),session['csrf']):return self.respond(403,{'error':'请求校验失败，请重新登录'})
        if path=='/api/logout':
            with lock:sessions.pop(token,None)
            return self.respond(200,{'ok':True},cookie='inspection_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0')
        if path!='/api/predict':return self.respond(404,{'error':'地址不存在'})
        now=time.time();key=(session['username'],self.client_address[0]);day=session['username']+':day:'+time.strftime('%Y-%m-%d');month=session['username']+':month:'+time.strftime('%Y-%m')
        with lock:
            history=rates[key]
            while history and now-history[0]>60:history.popleft()
            if len(history)>=90 or quotas.get(day,0)>=3000 or quotas.get(month,0)>=30000:return self.respond(429,{'error':'已达到调用限额，请稍后再试'})
            history.append(now);quotas[day]=quotas.get(day,0)+1;quotas[month]=quotas.get(month,0)+1;temporary=quota_path.with_suffix('.tmp');temporary.write_text(json.dumps(quotas));temporary.replace(quota_path)
        if not inference_lock.acquire(blocking=False):return self.respond(429,{'error':'模型正在处理上一张图片'})
        try:
            if 'preset' in data:
                preset=presets.get(str(data['preset']))
                if not preset:raise ValueError('预设图片不存在')
                raw=(ROOT/'data/raw'/preset['path']).read_bytes()
            else:raw=base64.b64decode(str(data.get('image','')).split(',')[-1],validate=True)
            if len(raw)>2_500_000:raise ValueError('图片请小于二点五兆字节')
            image=Image.open(io.BytesIO(raw))
            if image.width*image.height>12_000_000 or min(image.size)<32:raise ValueError('图片尺寸超出支持范围')
            result=model.json_result(image);audit_event('inference',session['username'],input_sha256=hashlib.sha256(raw).hexdigest(),score=result['score'],decision=result['predicted_label'],pipeline_ms=result['timing']['pipeline_ms']);return self.respond(200,result)
        except (ValueError,UnidentifiedImageError,OSError,Image.DecompressionBombError):return self.respond(400,{'error':'图片无法读取，请选择有效的工业产品图片'})
        except Exception as error:audit_event('inference_error',session['username'],error_type=type(error).__name__);return self.respond(500,{'error':'识别未完成，请重试或查看本机服务日志'})
        finally:inference_lock.release()
if __name__=='__main__':
    print('本机真实模型工作台：http://127.0.0.1:4288/；账号保存在仓库外的本机私密目录。',flush=True)
    ThreadingHTTPServer(('127.0.0.1',4288),Handler).serve_forever()
