"""Small supervised U-Net with an image-level anomaly head. No label used at inference."""
import torch
from torch import nn
import torch.nn.functional as F
class Block(nn.Module):
    def __init__(self,cin,cout):
        super().__init__();self.layers=nn.Sequential(nn.Conv2d(cin,cout,3,padding=1),nn.GroupNorm(4,cout),nn.SiLU(),nn.Conv2d(cout,cout,3,padding=1),nn.GroupNorm(4,cout),nn.SiLU())
    def forward(self,x):return self.layers(x)
class InspectionNet(nn.Module):
    def __init__(self):
        super().__init__();self.e1=Block(3,12);self.e2=Block(12,24);self.e3=Block(24,48);self.center=Block(48,96);self.d3=Block(144,48);self.d2=Block(72,24);self.d1=Block(36,12);self.mask=nn.Conv2d(12,1,1);self.classifier=nn.Sequential(nn.AdaptiveAvgPool2d(1),nn.Flatten(),nn.Linear(96,32),nn.SiLU(),nn.Dropout(.1),nn.Linear(32,1))
    def forward(self,x):
        a=self.e1(x);b=self.e2(F.avg_pool2d(a,2));c=self.e3(F.avg_pool2d(b,2));z=self.center(F.avg_pool2d(c,2));d=self.d3(torch.cat((F.interpolate(z,size=c.shape[-2:],mode='bilinear',align_corners=False),c),1));d=self.d2(torch.cat((F.interpolate(d,size=b.shape[-2:],mode='bilinear',align_corners=False),b),1));d=self.d1(torch.cat((F.interpolate(d,size=a.shape[-2:],mode='bilinear',align_corners=False),a),1));return self.mask(d),self.classifier(z).flatten()
