"""Download the pinned public metal-nut data and freeze a custom supervised split."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict,Counter
import json,subprocess,hashlib,random,time
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
REPO='MSherbinii/mvtec-ad-metal-nut'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    if not Path('/Volumes/T7').is_dir():raise RuntimeError('请先连接T7移动硬盘')
    if not str(ROOT.resolve()).startswith('/Volumes/T7/'):raise RuntimeError('请先把完整训练工程放在T7上，防止原始数据写入内置盘')
    remote=json.loads((ROOT/'data/remote-manifest.json').read_text())
    revision=remote['sha'];base=f'https://huggingface.co/datasets/{REPO}/resolve/{revision}/'
    def fetch(name):
        path=ROOT/'data/raw'/name
        if path.exists():
            with Image.open(path) as image:image.verify()
            return name
        path.parent.mkdir(parents=True,exist_ok=True);temporary=path.with_suffix('.part')
        subprocess.run(['curl','-fLsS','--retry','3','--retry-delay','2','--max-time','65',base+name,'-o',str(temporary)],check=True)
        with Image.open(temporary) as image:image.verify()
        temporary.replace(path);return name
    done=0;started=time.time()
    with ThreadPoolExecutor(max_workers=8) as pool:
        for future in as_completed([pool.submit(fetch,name) for name in remote['files']]):
            future.result();done+=1
            if done%30==0:print(json.dumps({'downloaded':done,'total':len(remote['files']),'seconds':round(time.time()-started)},ensure_ascii=False),flush=True)
    groups=defaultdict(list)
    for name in remote['files']:
        parts=name.split('/')
        if parts[1]=='ground_truth':continue
        groups[(parts[1],parts[2])].append(name)
    rng=random.Random(42);records=[]
    for (original,kind),names in sorted(groups.items()):
        names=sorted(names);rng.shuffle(names)
        for i,name in enumerate(names):
            if original=='train':split='train' if i<176 else 'val' if i<198 else 'test'
            elif kind=='good':split='test'
            else:
                train=int(len(names)*.6);val=int(len(names)*.2)
                split='train' if i<train else 'val' if i<train+val else 'test'
            mask=f'metal_nut/ground_truth/{kind}/{Path(name).stem}_mask.png' if kind!='good' else None
            path=ROOT/'data/raw'/name
            records.append({'path':name,'original_split':original,'kind':kind,'label':int(kind!='good'),'split':split,'mask':mask,'sha256':digest(path),'mask_sha256':digest(ROOT/'data/raw'/mask) if mask else None})
    hashes=defaultdict(set)
    for r in records:hashes[r['sha256']].add(r['split'])
    collisions=[h for h,splits in hashes.items() if len(splits)>1]
    if collisions:raise RuntimeError('Exact-image overlap across splits; stop before fitting')
    result={'seed':42,'protocol':'Custom supervised split; NOT the original MVTec unsupervised benchmark. 60% of each defect type trains the model, 20% calibrates, remainder is held out. Normal original training images split 176/22/22; all original test normals held out.','revision':revision,'counts':dict(Counter(r['split'] for r in records)),'by_split':{s:dict(Counter(r['kind'] for r in records if r['split']==s)) for s in ['train','val','test']},'exact_hash_cross_split_overlap':0,'records':records}
    (ROOT/'data/split.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({'prepared':len(records),'counts':result['counts'],'by_split':result['by_split'],'exact_hash_cross_split_overlap':0},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
