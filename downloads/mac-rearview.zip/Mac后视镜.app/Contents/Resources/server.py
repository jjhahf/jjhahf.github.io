import http.server, socketserver, os, threading, time, webbrowser

BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)

class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass

class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True

with Server(("127.0.0.1", 0), Handler) as httpd:
    port = httpd.server_address[1]
    url = f"http://127.0.0.1:{port}/index.html?v=10"

    def open_browser():
        time.sleep(0.45)
        webbrowser.open(url)

    threading.Thread(target=open_browser, daemon=True).start()
    httpd.serve_forever()
